#pragma once

#include "glApplication.h"

class myApplication : public cwc::glApplication
{
public:
	virtual void OnInit();
};
